package com.powerpuff.daylog.signup

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.powerpuff.daylog.R
import com.powerpuff.daylog.customview.CustomEditText
import com.powerpuff.daylog.customview.CustomPassword
import com.powerpuff.daylog.customview.CustomTextInput
import com.powerpuff.daylog.signin.SignInActivity
import com.powerpuff.daylog.profile.EditProfileActivity
import com.powerpuff.daylog.utils.HelperClass

class SignUpActivity : AppCompatActivity() {

    private lateinit var signupName: CustomTextInput
    private lateinit var signupUsername: CustomTextInput
    private lateinit var signupEmail: CustomEditText
    private lateinit var signupPassword: CustomPassword
    private lateinit var loginRedirectText: TextView
    private lateinit var signupButton: Button
    private lateinit var database: FirebaseDatabase
    private lateinit var reference: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_up)

        signupName = findViewById(R.id.signup_name)
        signupEmail = findViewById(R.id.signup_email)
        signupUsername = findViewById(R.id.signup_username)
        signupPassword = findViewById(R.id.signup_password)
        loginRedirectText = findViewById(R.id.loginRedirectText)
        signupButton = findViewById(R.id.signup_button)

        signupButton.setOnClickListener {
            val isNameValid = signupName.isValid ?: false
            val isEmailValid = signupEmail.isValid ?: false
            val isUsernameValid = signupUsername.isValid ?: false
            val isPasswordValid = signupPassword.isValid ?: false

            if (!isNameValid || !isEmailValid || !isUsernameValid || !isPasswordValid) {
                Toast.makeText(this@SignUpActivity, "Please fill in all fields correctly.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            // Proses signup hanya jika semua validasi terpenuhi
            database = FirebaseDatabase.getInstance()
            reference = database.getReference("users")

            val name = signupName.text.toString()
            val email = signupEmail.text.toString()
            val username = signupUsername.text.toString()
            val password = signupPassword.text.toString()

            val helperClass = HelperClass(name, email, username, password)
            reference.child(username).setValue(helperClass)

            Toast.makeText(this@SignUpActivity, "You have signed up successfully!", Toast.LENGTH_SHORT).show()

            // Pass data to EditProfileActivity
            val intentEditProfile = Intent(this@SignUpActivity, EditProfileActivity::class.java)
            intentEditProfile.putExtra("name", name)
            intentEditProfile.putExtra("email", email)
            intentEditProfile.putExtra("username", username)
            intentEditProfile.putExtra("password", password)
            startActivity(intentEditProfile)

            // Pass data to SignInActivity (optional if needed)
            val intentSignIn = Intent(this@SignUpActivity, SignInActivity::class.java)
            startActivity(intentSignIn)
        }


        loginRedirectText.setOnClickListener {
            val intent = Intent(this@SignUpActivity, SignInActivity::class.java)
            startActivity(intent)
        }

        supportActionBar?.hide()
    }
}
