package com.powerpuff.daylog.utils

data class DayInfo(
    val dayTextId: Int,
    val dateTextId: Int,
    val layoutId: Int,
    val calendarDay: Int
)

