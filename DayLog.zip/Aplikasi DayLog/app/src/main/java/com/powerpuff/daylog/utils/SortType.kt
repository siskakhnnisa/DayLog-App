package com.powerpuff.daylog.utils

enum class SortType {

    TIME,

    COURSE_NAME,

    LECTURER

}