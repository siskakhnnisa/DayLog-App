package com.powerpuff.daylog.utils

data class HelperClass(
    var name: String = "",
    var email: String = "",
    var username: String = "",
    var password: String = ""
)
