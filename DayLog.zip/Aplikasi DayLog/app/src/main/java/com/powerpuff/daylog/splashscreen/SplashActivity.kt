package com.powerpuff.daylog.splashscreen

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import androidx.appcompat.app.AppCompatActivity
import com.powerpuff.daylog.R
import com.powerpuff.daylog.signup.SignUpActivity

class SplashActivity : AppCompatActivity() {
    private val SPLASH_DELAY: Long = 3000 // Delay dalam milidetik (misalnya 3000 untuk 3 detik)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        // Handler untuk menangani delay dan intent ke SignUpActivity
        Handler().postDelayed({
            val intent = Intent(this@SplashActivity, SignUpActivity::class.java)
            startActivity(intent)
            finish() // Menutup SplashActivity agar tidak bisa kembali saat tombol back ditekan
        }, SPLASH_DELAY)
    }
}
